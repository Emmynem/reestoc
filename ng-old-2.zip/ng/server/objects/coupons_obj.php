<?php

  header("Access-Control-Allow-Origin: *");
  header("Content-Type: application/json; charset=UTF-8");
  ini_set('display_errors', 1);

  include_once 'functions.php';

  class Coupons{

      // database connection and table name
      private $conn;
      private $table_name = "coupons";

      // object properties
      public $id;
      public $unique_id;
      public $user_unique_id;
      public $product_unique_id;
      public $code;
      public $name;
      public $price;
      public $total_count;
      public $current_count;
      public $completion;
      public $expiry_date;
      public $added_date;
      public $last_modified;
      public $status;

      private $functions;
      private $products;
      private $not_allowed_values;

      public $output = array('error' => false, 'success' => false);

      // constructor with $db as database connection
      public function __construct($db){
          $this->conn = $db;
          $this->functions = new Functions();
          $this->not_allowed_values = $this->functions->not_allowed_values;
      }

      public function get_all_coupons(){

        try {
          $this->conn->beginTransaction();

          $sql = "SELECT coupons.id, coupons.unique_id, coupons.user_unique_id, coupons.product_unique_id, coupons.code, coupons.name, coupons.price, coupons.total_count, coupons.current_count, coupons.completion, coupons.expiry_date, coupons.added_date, coupons.last_modified, coupons.status,
          users.fullname as user_fullname, products.name as product_name FROM coupons LEFT JOIN users ON coupons.user_unique_id = users.unique_id LEFT JOIN products ON coupons.product_unique_id = products.unique_id ORDER BY coupons.added_date DESC";
          $query = $this->conn->prepare($sql);
          $query->execute();

          $result = $query->fetchAll();

          if ($query->rowCount() > 0) {
            return $result;
          }
          else {
            $output['error'] = true;
            $output['message'] = "Empty";
            return $output;
          }

          $this->conn->commit();
        } catch (PDOException $e) {
          $this->conn->rollback();
          throw $e;
        }

      }

      public function get_user_coupons($user_unique_id){
        if (!in_array($user_unique_id,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $null = $this->functions->null;

            $sql = "SELECT coupons.id, coupons.unique_id, coupons.user_unique_id, coupons.product_unique_id, coupons.code, coupons.name, coupons.price, coupons.total_count, coupons.current_count, coupons.completion, coupons.expiry_date, coupons.added_date, coupons.last_modified, coupons.status,
            users.fullname as user_fullname, products.name as product_name FROM coupons LEFT JOIN users ON coupons.user_unique_id = users.unique_id LEFT JOIN products ON coupons.product_unique_id = products.unique_id WHERE coupons.user_unique_id=:user_unique_id OR coupons.product_unique_id IS NOT NULL ORDER BY coupons.added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":user_unique_id", $user_unique_id);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              return $result;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }

      }

      public function get_product_coupons($product_unique_id){
        if (!in_array($product_unique_id,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $null = $this->functions->null;

            $sql = "SELECT coupons.id, coupons.unique_id, coupons.user_unique_id, coupons.product_unique_id, coupons.code, coupons.name, coupons.price, coupons.total_count, coupons.current_count, coupons.completion, coupons.expiry_date, coupons.added_date, coupons.last_modified, coupons.status,
            users.fullname as user_fullname, products.name as product_name FROM coupons LEFT JOIN users ON coupons.user_unique_id = users.unique_id LEFT JOIN products ON coupons.product_unique_id = products.unique_id WHERE coupons.product_unique_id=:product_unique_id ORDER BY coupons.added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":product_unique_id", $product_unique_id);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              return $result;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }

      }

  }

?>
