<?php

  header("Access-Control-Allow-Origin: *");
  header("Content-Type: application/json; charset=UTF-8");
  ini_set('display_errors', 1);

  include_once 'functions.php';

  class Cart{

      // database connection and table name
      private $conn;
      private $table_name = "carts";

      // object properties
      public $id;
      public $unique_id;
      public $user_unique_id;
      public $product_unique_id;
      public $quantity;
      public $added_date;
      public $last_modified;
      public $status;

      private $functions;
      private $not_allowed_values;

      public $output = array('error' => false, 'success' => false);

      // constructor with $db as database connection
      public function __construct($db){
          $this->conn = $db;
          $this->functions = new Functions();
          $this->not_allowed_values = $this->functions->not_allowed_values;
      }

      function get_all_cart(){

        try {
          $this->conn->beginTransaction();

          $active = $this->functions->active;
          $date_added = $this->functions->today;

          $cart_array = array();

          $sql = "SELECT carts.id, carts.unique_id, carts.user_unique_id, carts.product_unique_id, carts.quantity, carts.description, carts.added_date, carts.last_modified, carts.status, users.fullname as user_fullname,
          users.email as user_email, users.phone_number as user_phone_number, users.phone_number as user_phone_number, products.name, products.size, products.stripped, products.brand_unique_id, products.stock, products.stock_remaining, products.price, products.sales_price, products.favorites, brands.name as brand_name, brands.stripped as brand_name_stripped FROM carts
          INNER JOIN users ON carts.user_unique_id = users.unique_id LEFT JOIN products ON carts.product_unique_id = products.unique_id LEFT JOIN brands ON products.brand_unique_id = brands.unique_id ORDER BY carts.added_date DESC";
          $query = $this->conn->prepare($sql);
          $query->execute();

          $result = $query->fetchAll();

          if ($query->rowCount() > 0) {
            foreach ($result as $key => $value) {

              $current_cart = array();
              $current_cart['id'] = $value['id'];
              $current_cart['unique_id'] = $value['unique_id'];
              $current_cart['user_unique_id'] = $value['user_unique_id'];
              $current_cart['product_unique_id'] = $value['product_unique_id'];
              $current_cart['quantity'] = $value['quantity'];
              $current_cart['description'] = $value['description'];
              $current_cart['user_fullname'] = $value['user_fullname'];
              $current_cart['user_email'] = $value['user_email'];
              $current_cart['user_phone_number'] = $value['user_phone_number'];
              $current_cart['quantity'] = $value['quantity'];
              $current_cart['added_date'] = $value['added_date'];
              $current_cart['last_modified'] = $value['last_modified'];
              $current_cart['status'] = $value['status'];
              $current_cart['name'] = $value['name'];
              $current_cart['size'] = $value['size'];
              $current_cart['stripped'] = $value['stripped'];
              $current_cart['brand_unique_id'] = $value['brand_unique_id'];
              $current_cart['stock'] = $value['stock'];
              $current_cart['stock_remaining'] = $value['stock_remaining'];
              $current_cart['price'] = $value['price'];
              $current_cart['sales_price'] = $value['sales_price'];
              $current_cart['favorites'] = $value['favorites'];
              $current_cart['brand_name'] = $value['brand_name'];
              $current_cart['brand_name_stripped'] = $value['brand_name_stripped'];

              $product_id = $value['product_unique_id'];
              $cart_unique_id = $value['unique_id'];
              $user_unique_id = $value['user_unique_id'];

              $current_cart_price = (int)$value['price'];
              $current_cart_sales_price = (int)$value['sales_price'];
              $current_cart_quantity = (int)$value['quantity'];

              $sql2 = "SELECT image FROM product_images WHERE product_unique_id=:product_unique_id LIMIT 1";
              $query2 = $this->conn->prepare($sql2);
              $query2->bindParam(":product_unique_id", $product_id);
              $query2->execute();

              $images_result = $query2->fetchAll();

              if ($query2->rowCount() > 0) {
                $current_cart_images = array();

                foreach ($images_result as $key => $image_value) {
                  $current_cart_images[] = $image_value['image'];
                }

                $current_cart['cart_product_images'] = $current_cart_images;
              }
              else{
                $current_cart['cart_product_images'] = null;
              }

              if ($current_cart_sales_price != 0) {
                $sql7 = "SELECT offered_service_unique_id FROM order_services WHERE user_unique_id=:user_unique_id AND cart_unique_id=:cart_unique_id";
                $query7 = $this->conn->prepare($sql7);
                $query7->bindParam(":user_unique_id", $user_unique_id);
                $query7->bindParam(":cart_unique_id", $cart_unique_id);
                $query7->execute();

                if ($query7->rowCount() > 0) {
                  $the_cart_services_details = $query7->fetchAll();
                  $offered_services_price = 0;

                  foreach ($the_cart_services_details as $key => $value) {
                    $offered_service_unique_id = $value["offered_service_unique_id"];
                    $sql8 = "SELECT price FROM offered_services WHERE unique_id=:unique_id AND product_unique_id=:product_unique_id AND status=:status";
                    $query8 = $this->conn->prepare($sql8);
                    $query8->bindParam(":unique_id", $offered_service_unique_id);
                    $query8->bindParam(":product_unique_id", $product_id);
                    $query8->bindParam(":status", $active);
                    $query8->execute();

                    $the_offered_services_price_details = $query8->fetch();
                    $the_offered_services_price = (int)$the_offered_services_price_details[0];
                    if ($query8->rowCount() > 0) {
                      $offered_services_price += $the_offered_services_price;
                    }
                    else{
                      $offered_services_price = 0;
                    }
                  }

                  $current_cart['total_cart_amount'] = ($current_cart_sales_price * $current_cart_quantity) + ($offered_services_price * $current_cart_quantity);

                }
                else {
                  $current_cart['total_cart_amount'] = $current_cart_sales_price * $current_cart_quantity;
                }
              }
              else {
                $sql7 = "SELECT offered_service_unique_id FROM order_services WHERE user_unique_id=:user_unique_id AND cart_unique_id=:cart_unique_id";
                $query7 = $this->conn->prepare($sql7);
                $query7->bindParam(":user_unique_id", $user_unique_id);
                $query7->bindParam(":cart_unique_id", $cart_unique_id);
                $query7->execute();

                if ($query7->rowCount() > 0) {
                  $the_cart_services_details = $query7->fetchAll();
                  $offered_services_price = 0;

                  foreach ($the_cart_services_details as $key => $value) {
                    $offered_service_unique_id = $value["offered_service_unique_id"];

                    $sql8 = "SELECT price FROM offered_services WHERE unique_id=:unique_id AND product_unique_id=:product_unique_id AND status=:status";
                    $query8 = $this->conn->prepare($sql8);
                    $query8->bindParam(":unique_id", $offered_service_unique_id);
                    $query8->bindParam(":product_unique_id", $product_id);
                    $query8->bindParam(":status", $active);
                    $query8->execute();

                    $the_offered_services_price_details = $query8->fetch();
                    $the_offered_services_price = (int)$the_offered_services_price_details[0];
                    if ($query8->rowCount() > 0) {
                      $offered_services_price += $the_offered_services_price;
                    }
                    else{
                      $offered_services_price = 0;
                    }

                  }

                  $current_cart['total_cart_amount'] = ($current_cart_price * $current_cart_quantity) + ($offered_services_price * $current_cart_quantity);

                }
                else {
                  $current_cart['total_cart_amount'] = $current_cart_price * $current_cart_quantity;
                }
              }

              $sql7 = "SELECT offered_service_unique_id FROM order_services WHERE user_unique_id=:user_unique_id AND cart_unique_id=:cart_unique_id";
              $query7 = $this->conn->prepare($sql7);
              $query7->bindParam(":user_unique_id", $user_unique_id);
              $query7->bindParam(":cart_unique_id", $cart_unique_id);
              $query7->execute();

              if ($query7->rowCount() > 0) {
                $the_cart_services_details = $query7->fetchAll();

                $current_cart_offered_services = array();
                $current_cart_offered_services_price = array();
                $current_cart_offered_services_unique_id = array();

                $total_offered_services_amount = 0;

                foreach ($the_cart_services_details as $key => $value) {
                  $offered_service_unique_id = $value["offered_service_unique_id"];
                  $sql8 = "SELECT price, service FROM offered_services WHERE unique_id=:unique_id AND product_unique_id=:product_unique_id AND status=:status";
                  $query8 = $this->conn->prepare($sql8);
                  $query8->bindParam(":unique_id", $offered_service_unique_id);
                  $query8->bindParam(":product_unique_id", $product_id);
                  $query8->bindParam(":status", $active);
                  $query8->execute();

                  $the_offered_services_details = $query8->fetch();
                  $the_offered_services_price = (int)$the_offered_services_details[0];
                  $the_offered_services_service = $the_offered_services_details[1];

                  if ($query8->rowCount() > 0) {

                    $current_cart_offered_services[] = $the_offered_services_service;

                    $current_cart['cart_offered_services'] = $current_cart_offered_services;

                    $current_cart_offered_services_price[] = $the_offered_services_price;

                    $total_offered_services_amount += $the_offered_services_price;

                    $current_cart['cart_offered_services_price'] = $current_cart_offered_services_price;

                    $current_cart_offered_services_unique_id[] = $offered_service_unique_id;

                    $current_cart['cart_offered_services_unique_ids'] = $current_cart_offered_services_unique_id;

                  }
                  else{
                    $current_cart['cart_offered_services'] = null;
                    $current_cart['cart_offered_services_price'] = null;
                    $current_cart['cart_offered_services_unique_ids'] = null;
                  }
                }

                $current_cart['cart_offered_services_price_total_amount'] = $total_offered_services_amount * $current_cart_quantity;

              }
              else {
                $current_cart['cart_offered_services'] = null;
                $current_cart['cart_offered_services_price'] = null;
                $current_cart['cart_offered_services_unique_ids'] = null;
                $current_cart['cart_offered_services_price_total_amount'] = null;
              }

              $cart_array[] = $current_cart;
            }
            return $cart_array;
          }
          else {
            $output['error'] = true;
            $output['message'] = "Empty";
            return $output;
          }

          $this->conn->commit();
        } catch (PDOException $e) {
          $this->conn->rollback();
          throw $e;
        }

      }

      function get_user_cart($user_unique_id){

        if (!in_array($user_unique_id,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $cart_array = array();
            $date_added = $this->functions->today;

            $active = $this->functions->active;

            $sql = "SELECT carts.id, carts.unique_id, carts.user_unique_id, carts.product_unique_id, carts.quantity, carts.description, carts.added_date, carts.last_modified, carts.status, users.fullname as user_fullname,
            users.email as user_email, users.phone_number as user_phone_number, products.name, products.size, products.stripped, products.brand_unique_id, products.stock, products.stock_remaining, products.price, products.sales_price, products.favorites, brands.name as brand_name, brands.stripped as brand_name_stripped FROM carts
            INNER JOIN users ON carts.user_unique_id = users.unique_id LEFT JOIN products ON carts.product_unique_id = products.unique_id LEFT JOIN brands ON products.brand_unique_id = brands.unique_id WHERE carts.user_unique_id =:user_unique_id AND carts.status=:status ORDER BY carts.added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":user_unique_id", $user_unique_id);
            $query->bindParam(":status", $active);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              foreach ($result as $key => $value) {

                $current_cart = array();
                $current_cart['id'] = $value['id'];
                $current_cart['unique_id'] = $value['unique_id'];
                $current_cart['user_unique_id'] = $value['user_unique_id'];
                $current_cart['product_unique_id'] = $value['product_unique_id'];
                $current_cart['quantity'] = $value['quantity'];
                $current_cart['description'] = $value['description'];
                $current_cart['user_fullname'] = $value['user_fullname'];
                $current_cart['user_email'] = $value['user_email'];
                $current_cart['user_phone_number'] = $value['user_phone_number'];
                $current_cart['quantity'] = $value['quantity'];
                $current_cart['added_date'] = $value['added_date'];
                $current_cart['last_modified'] = $value['last_modified'];
                $current_cart['status'] = $value['status'];
                $current_cart['name'] = $value['name'];
                $current_cart['size'] = $value['size'];
                $current_cart['stripped'] = $value['stripped'];
                $current_cart['brand_unique_id'] = $value['brand_unique_id'];
                $current_cart['stock'] = $value['stock'];
                $current_cart['stock_remaining'] = $value['stock_remaining'];
                $current_cart['price'] = $value['price'];
                $current_cart['sales_price'] = $value['sales_price'];
                $current_cart['favorites'] = $value['favorites'];
                $current_cart['brand_name'] = $value['brand_name'];
                $current_cart['brand_name_stripped'] = $value['brand_name_stripped'];

                $product_id = $value['product_unique_id'];
                $cart_unique_id = $value['unique_id'];

                $current_cart_price = (int)$value['price'];
                $current_cart_sales_price = (int)$value['sales_price'];
                $current_cart_quantity = (int)$value['quantity'];

                $sql2 = "SELECT image FROM product_images WHERE product_unique_id=:product_unique_id LIMIT 1";
                $query2 = $this->conn->prepare($sql2);
                $query2->bindParam(":product_unique_id", $product_id);
                $query2->execute();

                $images_result = $query2->fetchAll();

                if ($query2->rowCount() > 0) {
                  $current_cart_images = array();

                  foreach ($images_result as $key => $image_value) {
                    $current_cart_images[] = $image_value['image'];
                  }

                  $current_cart['cart_product_images'] = $current_cart_images;
                }
                else{
                  $current_cart['cart_product_images'] = null;
                }

                if ($current_cart_sales_price != 0) {
                  $sql7 = "SELECT offered_service_unique_id FROM order_services WHERE user_unique_id=:user_unique_id AND cart_unique_id=:cart_unique_id";
                  $query7 = $this->conn->prepare($sql7);
                  $query7->bindParam(":user_unique_id", $user_unique_id);
                  $query7->bindParam(":cart_unique_id", $cart_unique_id);
                  $query7->execute();

                  if ($query7->rowCount() > 0) {
                    $the_cart_services_details = $query7->fetchAll();
                    $offered_services_price = 0;

                    foreach ($the_cart_services_details as $key => $value) {
                      $offered_service_unique_id = $value["offered_service_unique_id"];
                      $sql8 = "SELECT price FROM offered_services WHERE unique_id=:unique_id AND product_unique_id=:product_unique_id AND status=:status";
                      $query8 = $this->conn->prepare($sql8);
                      $query8->bindParam(":unique_id", $offered_service_unique_id);
                      $query8->bindParam(":product_unique_id", $product_id);
                      $query8->bindParam(":status", $active);
                      $query8->execute();

                      $the_offered_services_price_details = $query8->fetch();
                      $the_offered_services_price = (int)$the_offered_services_price_details[0];
                      if ($query8->rowCount() > 0) {
                        $offered_services_price += $the_offered_services_price;
                      }
                      else{
                        $offered_services_price = 0;
                      }
                    }

                    $current_cart['total_cart_amount'] = ($current_cart_sales_price * $current_cart_quantity) + ($offered_services_price * $current_cart_quantity);

                  }
                  else {
                    $current_cart['total_cart_amount'] = $current_cart_sales_price * $current_cart_quantity;
                  }
                }
                else {
                  $sql7 = "SELECT offered_service_unique_id FROM order_services WHERE user_unique_id=:user_unique_id AND cart_unique_id=:cart_unique_id";
                  $query7 = $this->conn->prepare($sql7);
                  $query7->bindParam(":user_unique_id", $user_unique_id);
                  $query7->bindParam(":cart_unique_id", $cart_unique_id);
                  $query7->execute();

                  if ($query7->rowCount() > 0) {
                    $the_cart_services_details = $query7->fetchAll();
                    $offered_services_price = 0;

                    foreach ($the_cart_services_details as $key => $value) {
                      $offered_service_unique_id = $value["offered_service_unique_id"];

                      $sql8 = "SELECT price FROM offered_services WHERE unique_id=:unique_id AND product_unique_id=:product_unique_id AND status=:status";
                      $query8 = $this->conn->prepare($sql8);
                      $query8->bindParam(":unique_id", $offered_service_unique_id);
                      $query8->bindParam(":product_unique_id", $product_id);
                      $query8->bindParam(":status", $active);
                      $query8->execute();

                      $the_offered_services_price_details = $query8->fetch();
                      $the_offered_services_price = (int)$the_offered_services_price_details[0];
                      if ($query8->rowCount() > 0) {
                        $offered_services_price += $the_offered_services_price;
                      }
                      else{
                        $offered_services_price = 0;
                      }

                    }

                    $current_cart['total_cart_amount'] = ($current_cart_price * $current_cart_quantity) + ($offered_services_price * $current_cart_quantity);

                  }
                  else {
                    $current_cart['total_cart_amount'] = $current_cart_price * $current_cart_quantity;
                  }
                }

                $sql7 = "SELECT offered_service_unique_id FROM order_services WHERE user_unique_id=:user_unique_id AND cart_unique_id=:cart_unique_id";
                $query7 = $this->conn->prepare($sql7);
                $query7->bindParam(":user_unique_id", $user_unique_id);
                $query7->bindParam(":cart_unique_id", $cart_unique_id);
                $query7->execute();

                if ($query7->rowCount() > 0) {
                  $the_cart_services_details = $query7->fetchAll();

                  $current_cart_offered_services = array();
                  $current_cart_offered_services_price = array();
                  $current_cart_offered_services_unique_id = array();

                  $total_offered_services_amount = 0;

                  foreach ($the_cart_services_details as $key => $value) {
                    $offered_service_unique_id = $value["offered_service_unique_id"];
                    $sql8 = "SELECT price, service FROM offered_services WHERE unique_id=:unique_id AND product_unique_id=:product_unique_id AND status=:status";
                    $query8 = $this->conn->prepare($sql8);
                    $query8->bindParam(":unique_id", $offered_service_unique_id);
                    $query8->bindParam(":product_unique_id", $product_id);
                    $query8->bindParam(":status", $active);
                    $query8->execute();

                    $the_offered_services_details = $query8->fetch();
                    $the_offered_services_price = (int)$the_offered_services_details[0];
                    $the_offered_services_service = $the_offered_services_details[1];

                    if ($query8->rowCount() > 0) {

                      $current_cart_offered_services[] = $the_offered_services_service;

                      $current_cart['cart_offered_services'] = $current_cart_offered_services;

                      $current_cart_offered_services_price[] = $the_offered_services_price;

                      $total_offered_services_amount += $the_offered_services_price;

                      $current_cart['cart_offered_services_price'] = $current_cart_offered_services_price;

                      $current_cart_offered_services_unique_id[] = $offered_service_unique_id;

                      $current_cart['cart_offered_services_unique_ids'] = $current_cart_offered_services_unique_id;

                    }
                    else{
                      $current_cart['cart_offered_services'] = null;
                      $current_cart['cart_offered_services_price'] = null;
                      $current_cart['cart_offered_services_unique_ids'] = null;
                    }
                  }

                  $current_cart['cart_offered_services_price_total_amount'] = $total_offered_services_amount * $current_cart_quantity;

                }
                else {
                  $current_cart['cart_offered_services'] = null;
                  $current_cart['cart_offered_services_price'] = null;
                  $current_cart['cart_offered_services_unique_ids'] = null;
                  $current_cart['cart_offered_services_price_total_amount'] = null;
                }

                $cart_array[] = $current_cart;
              }
              return $cart_array;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
            $output['error'] = true;
            $output['message'] = "Critical error occured";
            return $output;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }

      }

      function get_user_cart_details($user_unique_id, $cart_unique_id){

        if (!in_array($user_unique_id,$this->not_allowed_values) && !in_array($cart_unique_id,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $cart_array = array();
            $date_added = $this->functions->today;

            $active = $this->functions->active;

            $sql = "SELECT carts.id, carts.unique_id, carts.user_unique_id, carts.product_unique_id, carts.quantity, carts.description, carts.added_date, carts.last_modified, carts.status, users.fullname as user_fullname,
            users.email as user_email, users.phone_number as user_phone_number, products.name, products.size, products.stripped, products.brand_unique_id, products.stock, products.stock_remaining, products.price, products.sales_price, products.favorites, brands.name as brand_name, brands.stripped as brand_name_stripped FROM carts
            INNER JOIN users ON carts.user_unique_id = users.unique_id LEFT JOIN products ON carts.product_unique_id = products.unique_id LEFT JOIN brands ON products.brand_unique_id = brands.unique_id WHERE carts.user_unique_id =:user_unique_id AND carts.unique_id =:cart_unique_id AND carts.status=:status ORDER BY carts.added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":user_unique_id", $user_unique_id);
            $query->bindParam(":cart_unique_id", $cart_unique_id);
            $query->bindParam(":status", $active);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              foreach ($result as $key => $value) {

                $current_cart = array();
                $current_cart['id'] = $value['id'];
                $current_cart['unique_id'] = $value['unique_id'];
                $current_cart['user_unique_id'] = $value['user_unique_id'];
                $current_cart['product_unique_id'] = $value['product_unique_id'];
                $current_cart['quantity'] = $value['quantity'];
                $current_cart['description'] = $value['description'];
                $current_cart['user_fullname'] = $value['user_fullname'];
                $current_cart['user_email'] = $value['user_email'];
                $current_cart['user_phone_number'] = $value['user_phone_number'];
                $current_cart['quantity'] = $value['quantity'];
                $current_cart['added_date'] = $value['added_date'];
                $current_cart['last_modified'] = $value['last_modified'];
                $current_cart['status'] = $value['status'];
                $current_cart['name'] = $value['name'];
                $current_cart['size'] = $value['size'];
                $current_cart['stripped'] = $value['stripped'];
                $current_cart['brand_unique_id'] = $value['brand_unique_id'];
                $current_cart['stock'] = $value['stock'];
                $current_cart['stock_remaining'] = $value['stock_remaining'];
                $current_cart['price'] = $value['price'];
                $current_cart['sales_price'] = $value['sales_price'];
                $current_cart['favorites'] = $value['favorites'];
                $current_cart['brand_name'] = $value['brand_name'];
                $current_cart['brand_name_stripped'] = $value['brand_name_stripped'];

                $product_id = $value['product_unique_id'];
                $cart_unique_id = $value['unique_id'];

                $current_cart_price = (int)$value['price'];
                $current_cart_sales_price = (int)$value['sales_price'];
                $current_cart_quantity = (int)$value['quantity'];

                $sql2 = "SELECT image FROM product_images WHERE product_unique_id=:product_unique_id LIMIT 1";
                $query2 = $this->conn->prepare($sql2);
                $query2->bindParam(":product_unique_id", $product_id);
                $query2->execute();

                $images_result = $query2->fetchAll();

                if ($query2->rowCount() > 0) {
                  $current_cart_images = array();

                  foreach ($images_result as $key => $image_value) {
                    $current_cart_images[] = $image_value['image'];
                  }

                  $current_cart['cart_product_images'] = $current_cart_images;
                }
                else{
                  $current_cart['cart_product_images'] = null;
                }

                if ($current_cart_sales_price != 0) {
                  $sql7 = "SELECT offered_service_unique_id FROM order_services WHERE user_unique_id=:user_unique_id AND cart_unique_id=:cart_unique_id";
                  $query7 = $this->conn->prepare($sql7);
                  $query7->bindParam(":user_unique_id", $user_unique_id);
                  $query7->bindParam(":cart_unique_id", $cart_unique_id);
                  $query7->execute();

                  if ($query7->rowCount() > 0) {
                    $the_cart_services_details = $query7->fetchAll();
                    $offered_services_price = 0;

                    foreach ($the_cart_services_details as $key => $value) {
                      $offered_service_unique_id = $value["offered_service_unique_id"];
                      $sql8 = "SELECT price FROM offered_services WHERE unique_id=:unique_id AND product_unique_id=:product_unique_id AND status=:status";
                      $query8 = $this->conn->prepare($sql8);
                      $query8->bindParam(":unique_id", $offered_service_unique_id);
                      $query8->bindParam(":product_unique_id", $product_id);
                      $query8->bindParam(":status", $active);
                      $query8->execute();

                      $the_offered_services_price_details = $query8->fetch();
                      $the_offered_services_price = (int)$the_offered_services_price_details[0];
                      if ($query8->rowCount() > 0) {
                        $offered_services_price += $the_offered_services_price;
                      }
                      else{
                        $offered_services_price = 0;
                      }
                    }

                    $current_cart['total_cart_amount'] = ($current_cart_sales_price * $current_cart_quantity) + ($offered_services_price * $current_cart_quantity);

                  }
                  else {
                    $current_cart['total_cart_amount'] = $current_cart_sales_price * $current_cart_quantity;
                  }
                }
                else {
                  $sql7 = "SELECT offered_service_unique_id FROM order_services WHERE user_unique_id=:user_unique_id AND cart_unique_id=:cart_unique_id";
                  $query7 = $this->conn->prepare($sql7);
                  $query7->bindParam(":user_unique_id", $user_unique_id);
                  $query7->bindParam(":cart_unique_id", $cart_unique_id);
                  $query7->execute();

                  if ($query7->rowCount() > 0) {
                    $the_cart_services_details = $query7->fetchAll();
                    $offered_services_price = 0;

                    foreach ($the_cart_services_details as $key => $value) {
                      $offered_service_unique_id = $value["offered_service_unique_id"];

                      $sql8 = "SELECT price FROM offered_services WHERE unique_id=:unique_id AND product_unique_id=:product_unique_id AND status=:status";
                      $query8 = $this->conn->prepare($sql8);
                      $query8->bindParam(":unique_id", $offered_service_unique_id);
                      $query8->bindParam(":product_unique_id", $product_id);
                      $query8->bindParam(":status", $active);
                      $query8->execute();

                      $the_offered_services_price_details = $query8->fetch();
                      $the_offered_services_price = (int)$the_offered_services_price_details[0];
                      if ($query8->rowCount() > 0) {
                        $offered_services_price += $the_offered_services_price;
                      }
                      else{
                        $offered_services_price = 0;
                      }

                    }

                    $current_cart['total_cart_amount'] = ($current_cart_price * $current_cart_quantity) + ($offered_services_price * $current_cart_quantity);

                  }
                  else {
                    $current_cart['total_cart_amount'] = $current_cart_price * $current_cart_quantity;
                  }
                }

                $sql7 = "SELECT offered_service_unique_id FROM order_services WHERE user_unique_id=:user_unique_id AND cart_unique_id=:cart_unique_id";
                $query7 = $this->conn->prepare($sql7);
                $query7->bindParam(":user_unique_id", $user_unique_id);
                $query7->bindParam(":cart_unique_id", $cart_unique_id);
                $query7->execute();

                if ($query7->rowCount() > 0) {
                  $the_cart_services_details = $query7->fetchAll();

                  $current_cart_offered_services = array();
                  $current_cart_offered_services_price = array();
                  $current_cart_offered_services_unique_id = array();

                  $total_offered_services_amount = 0;

                  foreach ($the_cart_services_details as $key => $value) {
                    $offered_service_unique_id = $value["offered_service_unique_id"];
                    $sql8 = "SELECT price, service FROM offered_services WHERE unique_id=:unique_id AND product_unique_id=:product_unique_id AND status=:status";
                    $query8 = $this->conn->prepare($sql8);
                    $query8->bindParam(":unique_id", $offered_service_unique_id);
                    $query8->bindParam(":product_unique_id", $product_id);
                    $query8->bindParam(":status", $active);
                    $query8->execute();

                    $the_offered_services_details = $query8->fetch();
                    $the_offered_services_price = (int)$the_offered_services_details[0];
                    $the_offered_services_service = $the_offered_services_details[1];

                    if ($query8->rowCount() > 0) {

                      $current_cart_offered_services[] = $the_offered_services_service;

                      $current_cart['cart_offered_services'] = $current_cart_offered_services;

                      $current_cart_offered_services_price[] = $the_offered_services_price;

                      $total_offered_services_amount += $the_offered_services_price;

                      $current_cart['cart_offered_services_price'] = $current_cart_offered_services_price;

                      $current_cart_offered_services_unique_id[] = $offered_service_unique_id;

                      $current_cart['cart_offered_services_unique_ids'] = $current_cart_offered_services_unique_id;

                    }
                    else{
                      $current_cart['cart_offered_services'] = null;
                      $current_cart['cart_offered_services_price'] = null;
                      $current_cart['cart_offered_services_unique_ids'] = null;
                    }
                  }

                  $current_cart['cart_offered_services_price_total_amount'] = $total_offered_services_amount * $current_cart_quantity;

                }
                else {
                  $current_cart['cart_offered_services'] = null;
                  $current_cart['cart_offered_services_price'] = null;
                  $current_cart['cart_offered_services_unique_ids'] = null;
                  $current_cart['cart_offered_services_price_total_amount'] = null;
                }

                $cart_array[] = $current_cart;
              }
              return $cart_array;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
            $output['error'] = true;
            $output['message'] = "Critical error occured";
            return $output;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }

      }

  }

?>
