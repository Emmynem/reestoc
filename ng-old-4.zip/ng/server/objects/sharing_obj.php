<?php

  header("Access-Control-Allow-Origin: *");
  header("Content-Type: application/json; charset=UTF-8");
  ini_set('display_errors', 1);

  include_once 'functions.php';

  class Sharing{

      // database connection and table name
      private $conn;
      private $table_name = "sharing_items";

      // object properties
      public $id;
      public $unique_id;
      public $user_unique_id;
      public $edit_user_unique_id;
      public $name;
      public $stripped;
      public $description;
      public $total_price;
      public $split_price;
      public $total_no_of_persons;
      public $current_no_of_persons;
      public $expiration;
      public $expiry_date;
      public $completion;
      public $added_date;
      public $last_modified;
      public $status;

      private $functions;
      private $sharing;
      private $not_allowed_values;

      public $output = array('error' => false, 'success' => false);

      // constructor with $db as database connection
      public function __construct($db){
          $this->conn = $db;
          $this->functions = new Functions();
          $this->not_allowed_values = $this->functions->not_allowed_values;
      }

      public function get_all_sharing(){

        try {
          $this->conn->beginTransaction();

          $sharing_array = array();

          $sql = "SELECT sharing_items.id, sharing_items.unique_id, sharing_items.user_unique_id, sharing_items.edit_user_unique_id, sharing_items.name, sharing_items.stripped, sharing_items.description, sharing_items.total_price, sharing_items.split_price, sharing_items.total_no_of_persons,
          sharing_items.current_no_of_persons, sharing_items.expiration, sharing_items.expiry_date, sharing_items.completion, sharing_items.added_date, sharing_items.last_modified, sharing_items.status, management.fullname as added_fullname, management_alt.fullname as edit_user_fullname FROM sharing_items
          INNER JOIN management ON sharing_items.user_unique_id = management.unique_id INNER JOIN management management_alt ON sharing_items.edit_user_unique_id = management_alt.unique_id ORDER BY sharing_items.added_date DESC";
          $query = $this->conn->prepare($sql);
          $query->execute();

          $result = $query->fetchAll();

          if ($query->rowCount() > 0) {
            foreach ($result as $key => $value) {

              $current_sharing = array();
              $current_sharing['id'] = $value['id'];
              $current_sharing['unique_id'] = $value['unique_id'];
              $current_sharing['user_unique_id'] = $value['user_unique_id'];
              $current_sharing['edit_user_unique_id'] = $value['edit_user_unique_id'];
              $current_sharing['name'] = $value['name'];
              $current_sharing['description'] = $value['description'];
              $current_sharing['total_price'] = $value['total_price'];
              $current_sharing['split_price'] = $value['split_price'];
              $current_sharing['total_no_of_persons'] = $value['total_no_of_persons'];
              $current_sharing['current_no_of_persons'] = $value['current_no_of_persons'];
              $current_sharing['expiration'] = $value['expiration'];
              $current_sharing['expiry_date'] = $value['expiry_date'];
              $current_sharing['completion'] = $value['completion'];
              $current_sharing['added_date'] = $value['added_date'];
              $current_sharing['last_modified'] = $value['last_modified'];
              $current_sharing['status'] = $value['status'];
              $current_sharing['added_fullname'] = $value['added_fullname'];
              $current_sharing['edit_user_fullname'] = $value['edit_user_fullname'];

              $sharing_id = $value['unique_id'];

              $sql2 = "SELECT image FROM sharing_images WHERE sharing_unique_id=:sharing_unique_id";
              $query2 = $this->conn->prepare($sql2);
              $query2->bindParam(":sharing_unique_id", $sharing_id);
              $query2->execute();

              $images_result = $query2->fetchAll();

              if ($query2->rowCount() > 0) {
                $current_sharing_images = array();

                foreach ($images_result as $key => $image_value) {
                  $current_sharing_images[] = $image_value['image'];
                }

                $current_sharing['sharing_images'] = $current_sharing_images;
              }
              else{
                $current_sharing['sharing_images'] = null;
              }

              $sharing_array[] = $current_sharing;
            }
            return $sharing_array;
          }
          else {
            $output['error'] = true;
            $output['message'] = "Empty";
            return $output;
          }

          $this->conn->commit();
        } catch (PDOException $e) {
          $this->conn->rollback();
          throw $e;
        }

      }

      public function get_sharing_filter($start_date, $end_date){

        if (!in_array($start_date,$this->not_allowed_values) && !in_array($end_date,$this->not_allowed_values)) {

          try {
            $this->conn->beginTransaction();

            $sharing_array = array();

            $sql = "SELECT sharing_items.id, sharing_items.unique_id, sharing_items.user_unique_id, sharing_items.edit_user_unique_id, sharing_items.name, sharing_items.stripped, sharing_items.description, sharing_items.total_price, sharing_items.split_price, sharing_items.total_no_of_persons,
            sharing_items.current_no_of_persons, sharing_items.expiration, sharing_items.expiry_date, sharing_items.completion, sharing_items.added_date, sharing_items.last_modified, sharing_items.status, management.fullname as added_fullname, management_alt.fullname as edit_user_fullname FROM sharing_items
            INNER JOIN management ON sharing_items.user_unique_id = management.unique_id INNER JOIN management management_alt ON sharing_items.edit_user_unique_id = management_alt.unique_id
            WHERE sharing_items.added_date >:start_date AND (sharing_items.added_date <:end_date OR sharing_items.added_date=:end_date) ORDER BY sharing_items.added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":start_date", $start_date);
            $query->bindParam(":end_date", $end_date);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              foreach ($result as $key => $value) {

                $current_sharing = array();
                $current_sharing['id'] = $value['id'];
                $current_sharing['unique_id'] = $value['unique_id'];
                $current_sharing['user_unique_id'] = $value['user_unique_id'];
                $current_sharing['edit_user_unique_id'] = $value['edit_user_unique_id'];
                $current_sharing['name'] = $value['name'];
                $current_sharing['description'] = $value['description'];
                $current_sharing['total_price'] = $value['total_price'];
                $current_sharing['split_price'] = $value['split_price'];
                $current_sharing['total_no_of_persons'] = $value['total_no_of_persons'];
                $current_sharing['current_no_of_persons'] = $value['current_no_of_persons'];
                $current_sharing['expiration'] = $value['expiration'];
                $current_sharing['expiry_date'] = $value['expiry_date'];
                $current_sharing['completion'] = $value['completion'];
                $current_sharing['added_date'] = $value['added_date'];
                $current_sharing['last_modified'] = $value['last_modified'];
                $current_sharing['status'] = $value['status'];
                $current_sharing['added_fullname'] = $value['added_fullname'];
                $current_sharing['edit_user_fullname'] = $value['edit_user_fullname'];

                $sharing_id = $value['unique_id'];

                $sql2 = "SELECT image FROM sharing_images WHERE sharing_unique_id=:sharing_unique_id";
                $query2 = $this->conn->prepare($sql2);
                $query2->bindParam(":sharing_unique_id", $sharing_id);
                $query2->execute();

                $images_result = $query2->fetchAll();

                if ($query2->rowCount() > 0) {
                  $current_sharing_images = array();

                  foreach ($images_result as $key => $image_value) {
                    $current_sharing_images[] = $image_value['image'];
                  }

                  $current_sharing['sharing_images'] = $current_sharing_images;
                }
                else{
                  $current_sharing['sharing_images'] = null;
                }

                $sharing_array[] = $current_sharing;
              }
              return $sharing_array;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }

        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }

      }

      public function get_sharing_expiry_date_filter($start_date, $end_date){

        if (!in_array($start_date,$this->not_allowed_values) && !in_array($end_date,$this->not_allowed_values)) {

          try {
            $this->conn->beginTransaction();

            $active = $this->functions->active;

            $sharing_array = array();

            $sql = "SELECT sharing_items.id, sharing_items.unique_id, sharing_items.user_unique_id, sharing_items.edit_user_unique_id, sharing_items.name, sharing_items.stripped, sharing_items.description, sharing_items.total_price, sharing_items.split_price, sharing_items.total_no_of_persons,
            sharing_items.current_no_of_persons, sharing_items.expiration, sharing_items.expiry_date, sharing_items.completion, sharing_items.added_date, sharing_items.last_modified, sharing_items.status, management.fullname as added_fullname, management_alt.fullname as edit_user_fullname FROM sharing_items
            INNER JOIN management ON sharing_items.user_unique_id = management.unique_id INNER JOIN management management_alt ON sharing_items.edit_user_unique_id = management_alt.unique_id
            WHERE sharing_items.expiration=:expiration AND sharing_items.expiry_date >:start_date AND (sharing_items.expiry_date <:end_date OR sharing_items.expiry_date=:end_date) ORDER BY sharing_items.added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":expiration", $active);
            $query->bindParam(":start_date", $start_date);
            $query->bindParam(":end_date", $end_date);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              foreach ($result as $key => $value) {

                $current_sharing = array();
                $current_sharing['id'] = $value['id'];
                $current_sharing['unique_id'] = $value['unique_id'];
                $current_sharing['user_unique_id'] = $value['user_unique_id'];
                $current_sharing['edit_user_unique_id'] = $value['edit_user_unique_id'];
                $current_sharing['name'] = $value['name'];
                $current_sharing['description'] = $value['description'];
                $current_sharing['total_price'] = $value['total_price'];
                $current_sharing['split_price'] = $value['split_price'];
                $current_sharing['total_no_of_persons'] = $value['total_no_of_persons'];
                $current_sharing['current_no_of_persons'] = $value['current_no_of_persons'];
                $current_sharing['expiration'] = $value['expiration'];
                $current_sharing['expiry_date'] = $value['expiry_date'];
                $current_sharing['completion'] = $value['completion'];
                $current_sharing['added_date'] = $value['added_date'];
                $current_sharing['last_modified'] = $value['last_modified'];
                $current_sharing['status'] = $value['status'];
                $current_sharing['added_fullname'] = $value['added_fullname'];
                $current_sharing['edit_user_fullname'] = $value['edit_user_fullname'];

                $sharing_id = $value['unique_id'];

                $sql2 = "SELECT image FROM sharing_images WHERE sharing_unique_id=:sharing_unique_id";
                $query2 = $this->conn->prepare($sql2);
                $query2->bindParam(":sharing_unique_id", $sharing_id);
                $query2->execute();

                $images_result = $query2->fetchAll();

                if ($query2->rowCount() > 0) {
                  $current_sharing_images = array();

                  foreach ($images_result as $key => $image_value) {
                    $current_sharing_images[] = $image_value['image'];
                  }

                  $current_sharing['sharing_images'] = $current_sharing_images;
                }
                else{
                  $current_sharing['sharing_images'] = null;
                }

                $sharing_array[] = $current_sharing;
              }
              return $sharing_array;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }

        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }

      }

      public function get_all_sharing_for_users(){

        try {
          $this->conn->beginTransaction();

          $active = $this->functions->active;

          $sharing_array = array();

          $sql = "SELECT sharing_items.unique_id, sharing_items.name, sharing_items.stripped, sharing_items.description, sharing_items.total_price, sharing_items.split_price, sharing_items.total_no_of_persons,
          sharing_items.current_no_of_persons, sharing_items.expiration, sharing_items.expiry_date, sharing_items.completion, sharing_items.added_date FROM sharing_items WHERE sharing_items.status=:status ORDER BY sharing_items.added_date DESC";
          $query = $this->conn->prepare($sql);
          $query->bindParam(":status", $active);
          $query->execute();

          $result = $query->fetchAll();

          if ($query->rowCount() > 0) {
            foreach ($result as $key => $value) {

              $current_sharing = array();
              $current_sharing['unique_id'] = $value['unique_id'];
              $current_sharing['name'] = $value['name'];
              $current_sharing['description'] = $value['description'];
              $current_sharing['total_price'] = $value['total_price'];
              $current_sharing['split_price'] = $value['split_price'];
              $current_sharing['total_no_of_persons'] = $value['total_no_of_persons'];
              $current_sharing['current_no_of_persons'] = $value['current_no_of_persons'];
              $current_sharing['expiration'] = $value['expiration'];
              $current_sharing['expiry_date'] = $value['expiry_date'];
              $current_sharing['completion'] = $value['completion'];
              $current_sharing['added_date'] = $value['added_date'];

              $sharing_id = $value['unique_id'];

              $sql2 = "SELECT image FROM sharing_images WHERE sharing_unique_id=:sharing_unique_id";
              $query2 = $this->conn->prepare($sql2);
              $query2->bindParam(":sharing_unique_id", $sharing_id);
              $query2->execute();

              $images_result = $query2->fetchAll();

              if ($query2->rowCount() > 0) {
                $current_sharing_images = array();

                foreach ($images_result as $key => $image_value) {
                  $current_sharing_images[] = $image_value['image'];
                }

                $current_sharing['sharing_images'] = $current_sharing_images;
              }
              else{
                $current_sharing['sharing_images'] = null;
              }

              $sharing_array[] = $current_sharing;
            }
            return $sharing_array;
          }
          else {
            $output['error'] = true;
            $output['message'] = "Empty";
            return $output;
          }

          $this->conn->commit();
        } catch (PDOException $e) {
          $this->conn->rollback();
          throw $e;
        }

      }

      public function get_sharing_details($unique_id, $stripped){
        if (!in_array($unique_id,$this->not_allowed_values) || !in_array($stripped,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $sharing_array = array();

            $sql = "SELECT sharing_items.id, sharing_items.unique_id, sharing_items.user_unique_id, sharing_items.edit_user_unique_id, sharing_items.name, sharing_items.stripped, sharing_items.description, sharing_items.total_price, sharing_items.split_price, sharing_items.total_no_of_persons,
            sharing_items.current_no_of_persons, sharing_items.expiration, sharing_items.expiry_date, sharing_items.completion, sharing_items.added_date, sharing_items.last_modified, sharing_items.status, management.fullname as added_fullname, management_alt.fullname as edit_user_fullname FROM sharing_items
            INNER JOIN management ON sharing_items.user_unique_id = management.unique_id INNER JOIN management management_alt ON sharing_items.edit_user_unique_id = management_alt.unique_id
            WHERE sharing_items.unique_id=:unique_id OR sharing_items.stripped=:stripped ORDER BY sharing_items.added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":unique_id", $unique_id);
            $query->bindParam(":stripped", $stripped);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              foreach ($result as $key => $value) {

                $current_sharing = array();
                $current_sharing['id'] = $value['id'];
                $current_sharing['unique_id'] = $value['unique_id'];
                $current_sharing['user_unique_id'] = $value['user_unique_id'];
                $current_sharing['edit_user_unique_id'] = $value['edit_user_unique_id'];
                $current_sharing['name'] = $value['name'];
                $current_sharing['description'] = $value['description'];
                $current_sharing['total_price'] = $value['total_price'];
                $current_sharing['split_price'] = $value['split_price'];
                $current_sharing['total_no_of_persons'] = $value['total_no_of_persons'];
                $current_sharing['current_no_of_persons'] = $value['current_no_of_persons'];
                $current_sharing['expiration'] = $value['expiration'];
                $current_sharing['expiry_date'] = $value['expiry_date'];
                $current_sharing['completion'] = $value['completion'];
                $current_sharing['added_date'] = $value['added_date'];
                $current_sharing['last_modified'] = $value['last_modified'];
                $current_sharing['status'] = $value['status'];
                $current_sharing['added_fullname'] = $value['added_fullname'];
                $current_sharing['edit_user_fullname'] = $value['edit_user_fullname'];

                $sharing_id = $value['unique_id'];

                $sql2 = "SELECT image FROM sharing_images WHERE sharing_unique_id=:sharing_unique_id";
                $query2 = $this->conn->prepare($sql2);
                $query2->bindParam(":sharing_unique_id", $sharing_id);
                $query2->execute();

                $images_result = $query2->fetchAll();

                if ($query2->rowCount() > 0) {
                  $current_sharing_images = array();

                  foreach ($images_result as $key => $image_value) {
                    $current_sharing_images[] = $image_value['image'];
                  }

                  $current_sharing['sharing_images'] = $current_sharing_images;
                }
                else{
                  $current_sharing['sharing_images'] = null;
                }

                $sharing_array[] = $current_sharing;
              }
              return $sharing_array;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "At least one value is required";
          return $output;
        }

      }

      public function get_sharing_details_for_users($unique_id, $stripped){
        if (!in_array($unique_id,$this->not_allowed_values) || !in_array($stripped,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $active = $this->functions->active;

            $sharing_array = array();

            $sql = "SELECT sharing_items.unique_id, sharing_items.name, sharing_items.stripped, sharing_items.description, sharing_items.total_price, sharing_items.split_price, sharing_items.total_no_of_persons,
            sharing_items.current_no_of_persons, sharing_items.expiration, sharing_items.expiry_date, sharing_items.completion, sharing_items.added_date FROM sharing_items WHERE (sharing_items.unique_id=:unique_id OR sharing_items.stripped=:stripped)
            AND sharing_items.status=:status ORDER BY sharing_items.added_date DESC LIMIT 1";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":unique_id", $unique_id);
            $query->bindParam(":stripped", $stripped);
            $query->bindParam(":status", $active);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              foreach ($result as $key => $value) {

                $current_sharing = array();
                $current_sharing['unique_id'] = $value['unique_id'];
                $current_sharing['name'] = $value['name'];
                $current_sharing['description'] = $value['description'];
                $current_sharing['total_price'] = $value['total_price'];
                $current_sharing['split_price'] = $value['split_price'];
                $current_sharing['total_no_of_persons'] = $value['total_no_of_persons'];
                $current_sharing['current_no_of_persons'] = $value['current_no_of_persons'];
                $current_sharing['expiration'] = $value['expiration'];
                $current_sharing['expiry_date'] = $value['expiry_date'];
                $current_sharing['completion'] = $value['completion'];
                $current_sharing['added_date'] = $value['added_date'];

                $sharing_id = $value['unique_id'];

                $sql2 = "SELECT image FROM sharing_images WHERE sharing_unique_id=:sharing_unique_id";
                $query2 = $this->conn->prepare($sql2);
                $query2->bindParam(":sharing_unique_id", $sharing_id);
                $query2->execute();

                $images_result = $query2->fetchAll();

                if ($query2->rowCount() > 0) {
                  $current_sharing_images = array();

                  foreach ($images_result as $key => $image_value) {
                    $current_sharing_images[] = $image_value['image'];
                  }

                  $current_sharing['sharing_images'] = $current_sharing_images;
                }
                else{
                  $current_sharing['sharing_images'] = null;
                }

                $sharing_array[] = $current_sharing;
              }
              return $sharing_array;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "At least one value is required";
          return $output;
        }

      }

      public function get_sharing_images($unique_id){
        if (!in_array($unique_id,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $sharing_array = array();

            $sql = "SELECT sharing_images.id, sharing_images.unique_id, sharing_images.user_unique_id, sharing_images.edit_user_unique_id, sharing_images.sharing_unique_id, sharing_images.image, sharing_images.file, sharing_images.file_size, sharing_images.added_date, sharing_images.last_modified, sharing_images.status,
            management.fullname as added_fullname, management_alt.fullname as edit_user_fullname, sharing_items.name as sharing_name FROM sharing_images INNER JOIN management ON sharing_images.user_unique_id = management.unique_id INNER JOIN management management_alt ON sharing_images.edit_user_unique_id = management_alt.unique_id
            LEFT JOIN sharing_items ON sharing_images.sharing_unique_id = sharing_items.unique_id WHERE sharing_images.sharing_unique_id=:sharing_unique_id ORDER BY sharing_images.added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":sharing_unique_id", $unique_id);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              return $result;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }
      }

      public function get_sharing_image_details($unique_id, $sharing_unique_id){
        if (!in_array($unique_id,$this->not_allowed_values) && !in_array($sharing_unique_id,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $sharing_array = array();

            $sql = "SELECT sharing_images.id, sharing_images.unique_id, sharing_images.user_unique_id, sharing_images.edit_user_unique_id, sharing_images.sharing_unique_id, sharing_images.image, sharing_images.file, sharing_images.file_size, sharing_images.added_date, sharing_images.last_modified, sharing_images.status,
            management.fullname as added_fullname, management_alt.fullname as edit_user_fullname, sharing_items.name as sharing_name FROM sharing_images INNER JOIN management ON sharing_images.user_unique_id = management.unique_id INNER JOIN management management_alt ON sharing_images.edit_user_unique_id = management_alt.unique_id
            LEFT JOIN sharing_items ON sharing_images.sharing_unique_id = sharing_items.unique_id WHERE sharing_images.unique_id=:unique_id AND sharing_images.sharing_unique_id=:sharing_unique_id ORDER BY sharing_items.added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":unique_id", $unique_id);
            $query->bindParam(":sharing_unique_id", $sharing_unique_id);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              return $result;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }
      }

      public function get_sharing_users($unique_id){
        if (!in_array($unique_id,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $active = $this->functions->active;

            $sharing_array = array();

            $sql = "SELECT sharing_users.id, sharing_users.unique_id, sharing_users.user_unique_id, sharing_users.sharing_unique_id, sharing_users.amount, sharing_users.paid, sharing_users.added_date, sharing_users.last_modified, sharing_users.status,
            users.fullname as user_fullname, users.email as user_email, users.phone_number as user_phone_number, sharing_items.name as sharing_name FROM sharing_users
            INNER JOIN users ON sharing_users.user_unique_id = users.unique_id
            INNER JOIN sharing_items ON sharing_users.sharing_unique_id = sharing_items.unique_id
            LEFT JOIN (SELECT COUNT(*) AS sharing_users_count, sharing_unique_id FROM sharing_users GROUP BY sharing_unique_id) AS sharing_users_count_table ON sharing_users.sharing_unique_id = sharing_users_count_table.sharing_unique_id
            LEFT JOIN (SELECT COUNT(*) AS sharing_paid_users_count, sharing_unique_id FROM sharing_users WHERE paid=:paid GROUP BY sharing_unique_id) AS sharing_paid_users_count_table ON sharing_users.sharing_unique_id = sharing_paid_users_count_table.sharing_unique_id
            WHERE sharing_users.sharing_unique_id=:sharing_unique_id ORDER BY sharing_users.added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":sharing_unique_id", $unique_id);
            $query->bindParam(":paid", $active);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              return $result;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }
      }

  }

?>
