<?php

  header("Access-Control-Allow-Origin: *");
  header("Content-Type: application/json; charset=UTF-8");
  ini_set('display_errors', 1);

  include_once 'functions.php';

  class Users{

      // database connection and table name
      private $conn;
      private $table_name = "users";

      // object properties
      public $id;
      public $unique_id;
      public $fullname;
      public $email;
      public $added_date;
      public $last_modified;
      public $access;
      public $status;

      private $functions;
      private $not_allowed_values;

      public $output = array('error' => false, 'success' => false);

      // constructor with $db as database connection
      public function __construct($db){
          $this->conn = $db;
          $this->functions = new Functions();
          $this->not_allowed_values = $this->functions->not_allowed_values;
      }

      function get_all_users(){
        try {
          $this->conn->beginTransaction();

          $sql = "SELECT * FROM users ORDER BY added_date DESC";
          $query = $this->conn->prepare($sql);
          $query->execute();

          $result = $query->fetchAll();

          if ($query->rowCount() > 0) {
            return $result;
          }
          else {
            $output['error'] = true;
            $output['message'] = "Empty";
            return $output;
          }

          $this->conn->commit();
        } catch (PDOException $e) {
          $this->conn->rollback();
          throw $e;
        }
      }

      function get_all_users_for_coupons(){
        try {
          $this->conn->beginTransaction();

          $sql = "SELECT users.unique_id, users.fullname, users.email, users.phone_number, ref_table.referrals_count, orders_completed_table.orders_completed_count FROM users
          LEFT JOIN (SELECT COUNT(*) AS referrals_count, referral_user_unique_id FROM referrals GROUP BY referral_user_unique_id) AS ref_table ON users.unique_id = ref_table.referral_user_unique_id
          LEFT JOIN (SELECT COUNT(*) AS orders_completed_count, user_unique_id FROM orders_completed GROUP BY user_unique_id) AS orders_completed_table ON users.unique_id = orders_completed_table.user_unique_id
          GROUP BY users.unique_id ORDER BY orders_completed_table.orders_completed_count DESC, ref_table.referrals_count DESC";
          $query = $this->conn->prepare($sql);
          $query->execute();

          $result = $query->fetchAll();

          if ($query->rowCount() > 0) {
            return $result;
          }
          else {
            $output['error'] = true;
            $output['message'] = "Empty";
            return $output;
          }

          $this->conn->commit();
        } catch (PDOException $e) {
          $this->conn->rollback();
          throw $e;
        }
      }

      function get_user_filter($start_date, $end_date){

        if (!in_array($start_date,$this->not_allowed_values) && !in_array($end_date,$this->not_allowed_values)) {

          $sql = "SELECT * FROM users WHERE added_date >:start_date AND (added_date <:end_date OR added_date=:end_date) ORDER BY added_date DESC";
          $query = $this->conn->prepare($sql);
          $query->bindParam(":start_date", $start_date);
          $query->bindParam(":end_date", $end_date);
          $query->execute();

          $result = $query->fetchAll();

          if ($query->rowCount() > 0) {
            return $result;
          }
          else {
            $output['error'] = true;
            $output['message'] = "Empty";
            return $output;
          }

        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }

      }

      function get_user_details($user_unique_id){
        if (!in_array($user_unique_id,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $sql = "SELECT * FROM users WHERE unique_id=:unique_id ORDER BY added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":unique_id", $user_unique_id);
            $query->execute();

            $result = $query->fetch();

            if ($query->rowCount() > 0) {
              return $result;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }

      }

      function get_user_referrals($user_unique_id){
        if (!in_array($user_unique_id,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $sql = "SELECT * FROM referrals WHERE referral_user_unique_id=:referral_user_unique_id ORDER BY added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":referral_user_unique_id", $user_unique_id);
            $query->execute();

            $result = $query->fetch();

            if ($query->rowCount() > 0) {
              return $result;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }

      }

  }
?>
