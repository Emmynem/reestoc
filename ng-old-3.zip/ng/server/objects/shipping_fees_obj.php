<?php

  header("Access-Control-Allow-Origin: *");
  header("Content-Type: application/json; charset=UTF-8");
  ini_set('display_errors', 1);

  include_once 'functions.php';

  class ShippingFees{

      // database connection and table name
      private $conn;
      private $table_name = "shipping_fees";

      // object properties
      public $id;
      public $unique_id;
      public $user_unique_id;
      public $edit_user_unique_id;
      public $sub_product_unique_id;
      public $location;
      public $price;
      public $added_date;
      public $last_modified;
      public $status;

      private $functions;
      private $not_allowed_values;

      public $output = array('error' => false, 'success' => false);

      // constructor with $db as database connection
      public function __construct($db){
          $this->conn = $db;
          $this->functions = new Functions();
          $this->not_allowed_values = $this->functions->not_allowed_values;
      }

      function get_all_shipping_fees(){

        try {
          $this->conn->beginTransaction();

          $sql = "SELECT shipping_fees.id, shipping_fees.unique_id, shipping_fees.user_unique_id, shipping_fees.edit_user_unique_id, shipping_fees.sub_product_unique_id, shipping_fees.city, shipping_fees.state, shipping_fees.country, shipping_fees.price,
          shipping_fees.added_date, shipping_fees.last_modified, shipping_fees.status, management.fullname as added_user_fullname, management_alt.fullname as edit_user_fullname, sub_products.name as sub_product_name, sub_products.size as sub_product_size FROM shipping_fees
          LEFT JOIN sub_products ON shipping_fees.sub_product_unique_id = sub_products.unique_id INNER JOIN management ON shipping_fees.user_unique_id = management.unique_id INNER JOIN management management_alt ON shipping_fees.edit_user_unique_id = management_alt.unique_id ORDER BY shipping_fees.added_date DESC";
          $query = $this->conn->prepare($sql);
          $query->execute();

          $result = $query->fetchAll();

          if ($query->rowCount() > 0) {
            return $result;
          }
          else {
            $output['error'] = true;
            $output['message'] = "Empty";
            return $output;
          }

          $this->conn->commit();
        } catch (PDOException $e) {
          $this->conn->rollback();
          throw $e;
        }

      }

      function get_sub_product_shipping_fees($sub_product_unique_id){
        if (!in_array($sub_product_unique_id,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $sql = "SELECT shipping_fees.id, shipping_fees.unique_id, shipping_fees.user_unique_id, shipping_fees.edit_user_unique_id, shipping_fees.sub_product_unique_id, shipping_fees.city, shipping_fees.state, shipping_fees.country, shipping_fees.price,
            shipping_fees.added_date, shipping_fees.last_modified, shipping_fees.status, sub_products.name as sub_product_name, sub_products.size as sub_product_size FROM shipping_fees
            LEFT JOIN sub_products ON shipping_fees.sub_product_unique_id = sub_products.unique_id WHERE shipping_fees.sub_product_unique_id=:sub_product_unique_id ORDER BY shipping_fees.added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":sub_product_unique_id", $sub_product_unique_id);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              return $result;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }

      }

      function get_sub_product_shipping_fees_for_users($sub_product_unique_id){
        if (!in_array($sub_product_unique_id,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $active = $this->functions->active;

            $sql = "SELECT shipping_fees.unique_id, shipping_fees.sub_product_unique_id, shipping_fees.city, shipping_fees.state, shipping_fees.country, shipping_fees.price, sub_products.name as sub_product_name, sub_products.size as sub_product_size FROM shipping_fees
            LEFT JOIN sub_products ON shipping_fees.sub_product_unique_id = sub_products.unique_id WHERE shipping_fees.sub_product_unique_id=:sub_product_unique_id AND shipping_fees.status=:status ORDER BY shipping_fees.added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":sub_product_unique_id", $sub_product_unique_id);
            $query->bindParam(":status", $active);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              return $result;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }

      }

  }
?>
