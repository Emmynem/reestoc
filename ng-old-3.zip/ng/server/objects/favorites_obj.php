<?php

  header("Access-Control-Allow-Origin: *");
  header("Content-Type: application/json; charset=UTF-8");
  ini_set('display_errors', 1);

  include_once 'functions.php';

  class Favorites{

      // database connection and table name
      private $conn;
      private $table_name = "favorites";

      // object properties
      public $id;
      public $unique_id;
      public $user_unique_id;
      public $product_unique_id;
      public $added_date;
      public $last_modified;
      public $status;

      private $functions;
      private $products;
      private $not_allowed_values;

      public $output = array('error' => false, 'success' => false);

      // constructor with $db as database connection
      public function __construct($db){
          $this->conn = $db;
          $this->functions = new Functions();
          $this->not_allowed_values = $this->functions->not_allowed_values;
      }

      public function get_all_favorites(){

        try {
          $this->conn->beginTransaction();

          $sql = "SELECT favorites.id, favorites.unique_id, favorites.user_unique_id, favorites.product_unique_id, favorites.added_date, favorites.last_modified, favorites.status, users.fullname as user_fullname, users.email as user_email, users.phone_number as user_phone_number, products.mini_category_unique_id, products.sub_category_unique_id, products.category_unique_id,
          products.name as product_name, products.brand_unique_id, products.description, products.key_features, products.specifications, products.accessories, products.stock,
          products.stock_remaining, products.price, products.sales_price, products.favorites, products.status as product_status, brands.name as brand_name FROM favorites
          INNER JOIN users ON favorites.user_unique_id = users.unique_id INNER JOIN products ON favorites.product_unique_id = products.unique_id LEFT JOIN brands ON products.brand_unique_id = brands.unique_id ORDER BY favorites.added_date DESC";
          $query = $this->conn->prepare($sql);
          $query->execute();

          $result = $query->fetchAll();

          if ($query->rowCount() > 0) {
            return $result;
          }
          else {
            $output['error'] = true;
            $output['message'] = "Empty";
            return $output;
          }

          $this->conn->commit();
        } catch (PDOException $e) {
          $this->conn->rollback();
          throw $e;
        }

      }

      public function get_user_favorites($user_unique_id){
        if (!in_array($user_unique_id,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $sql = "SELECT favorites.id, favorites.unique_id, favorites.user_unique_id, favorites.product_unique_id, favorites.added_date, favorites.last_modified, favorites.status,
            users.fullname as user_fullname, users.email as user_email, users.phone_number as user_phone_number, products.mini_category_unique_id, products.sub_category_unique_id, products.category_unique_id,
            products.name as product_name, products.brand_unique_id, products.description, products.key_features, products.specifications, products.accessories, products.stock,
            products.stock_remaining, products.price, products.sales_price, products.favorites, products.status as product_status, brands.name as brand_name FROM favorites
            INNER JOIN users ON favorites.user_unique_id = users.unique_id LEFT JOIN products ON favorites.product_unique_id = products.unique_id LEFT JOIN brands ON products.brand_unique_id = brands.unique_id WHERE favorites.user_unique_id=:user_unique_id ORDER BY favorites.added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":user_unique_id", $user_unique_id);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              return $result;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }

      }

  }

?>
