<?php

  require '../../config/connect_data.php';
  include_once "../../objects/functions.php";

  class genericClass {
    public $engineMessage = 0;
    public $engineError = 0;
    public $engineErrorMessage;
    public $resultData;
    public $filteredData;
  }

  $data = json_decode(file_get_contents("php://input"), true);

  $functions = new Functions();

  if ($connected) {

    try {
      $conn->beginTransaction();

      $date_added = $functions->today;
      $active = $functions->active;
      $not_allowed_values = $functions->not_allowed_values;

      $referral_user_unique_id = isset($_GET['referral_user_unique_id']) ? $_GET['referral_user_unique_id'] : $data['referral_user_unique_id'];
      $fullname = isset($_GET['fullname']) ? $_GET['fullname'] : $data['fullname'];
      $email = isset($_GET['email']) ? $_GET['email'] : $data['email'];
      $phone_number = isset($_GET['phone_number']) ? $_GET['phone_number'] : $data['phone_number'];

      $validation = $functions->add_new_user_validation($fullname, $email, $phone_number);

      if ($validation["error"] == true) {
        $returnvalue = new genericClass();
        $returnvalue->engineError = 2;
        $returnvalue->engineErrorMessage = $validation["message"];
      }
      else {

        $access = $functions->granted;

        $sql2 = "SELECT email FROM users WHERE email=:email OR phone_number=:phone_number";
        $query2 = $conn->prepare($sql2);
        $query2->bindParam(":email", $email);
        $query2->bindParam(":phone_number", $phone_number);
        $query2->execute();

        if ($query2->rowCount() > 0) {
          $returnvalue = new genericClass();
          $returnvalue->engineError = 2;
          $returnvalue->engineErrorMessage = "User already exists";
        }
        else {
          $unique_id = $functions->random_str(20);

          $the_email = in_array($email, $not_allowed_values) ? null : $email;
          $the_phone_number = in_array($phone_number, $not_allowed_values) ? null : $phone_number;

          $sql = "INSERT INTO users (unique_id, fullname, email, phone_number, added_date, last_modified, access, status)
          VALUES (:unique_id, :fullname, :email, :phone_number, :added_date, :last_modified, :access, :status)";
          $query = $conn->prepare($sql);
          $query->bindParam(":unique_id", $unique_id);
          $query->bindParam(":fullname", $fullname);
          $query->bindParam(":email", $the_email);
          $query->bindParam(":phone_number", $the_phone_number);
          $query->bindParam(":added_date", $date_added);
          $query->bindParam(":last_modified", $date_added);
          $query->bindParam(":access", $access);
          $query->bindParam(":status", $active);
          $query->execute();

          if ($query->rowCount() > 0) {

            $referral_unique_id = $functions->random_str(20);

            $the_referral_user_unique_id = in_array($referral_user_unique_id, $not_allowed_values) ? "Default" : $referral_user_unique_id;

            $user_referral_link = "https://reestoc.com/sign-up/".$unique_id;

            $sql3 = "INSERT INTO referrals (unique_id, referral_user_unique_id, user_unique_id, user_referral_link, added_date, last_modified, status)
            VALUES (:unique_id, :referral_user_unique_id, :user_unique_id, :user_referral_link, :added_date, :last_modified, :status)";
            $query3 = $conn->prepare($sql3);
            $query3->bindParam(":unique_id", $referral_unique_id);
            $query3->bindParam(":referral_user_unique_id", $the_referral_user_unique_id);
            $query3->bindParam(":user_unique_id", $unique_id);
            $query3->bindParam(":user_referral_link", $user_referral_link);
            $query3->bindParam(":added_date", $date_added);
            $query3->bindParam(":last_modified", $date_added);
            $query3->bindParam(":status", $active);
            $query3->execute();

            if ($query3->rowCount() > 0) {
              $returnvalue = new genericClass();
              $returnvalue->engineMessage = 1;
            }
            else {
              $returnvalue = new genericClass();
              $returnvalue->engineError = 2;
              $returnvalue->engineErrorMessage = "Not inserted (new user referral)";
            }
          }
          else{
            $returnvalue = new genericClass();
            $returnvalue->engineError = 2;
            $returnvalue->engineErrorMessage = "Not inserted (new user)";
          }
        }

      }

      $conn->commit();
    } catch (PDOException $e) {
      $conn->rollback();
      throw $e;
    }

  }
  else {
    $returnvalue = new genericClass();
    $returnvalue->engineError = 3;
    $returnvalue->engineErrorMessage = "No connection";
  }

  echo json_encode($returnvalue);

?>
