<?php

  require '../../config/connect_data.php';
  include_once "../../objects/functions.php";

  class genericClass {
    public $engineMessage = 0;
    public $engineError = 0;
    public $engineErrorMessage;
    public $resultData;
    public $filteredData;
  }

  $data = json_decode(file_get_contents("php://input"), true);

  $functions = new Functions();

  if ($connected) {

    try {
      $conn->beginTransaction();

      $date_added = $functions->today;
      $active = $functions->active;
      $not_allowed_values = $functions->not_allowed_values;

      $user_unique_id = isset($_GET['user_unique_id']) ? $_GET['user_unique_id'] : $data['user_unique_id'];
      $product_unique_id = isset($_GET['product_unique_id']) ? $_GET['product_unique_id'] : $data['product_unique_id'];
      $quantity = isset($_GET['quantity']) ? $_GET['quantity'] : $data['quantity'];
      $description = isset($_GET['description']) ? $_GET['description'] : $data['description'];
      $cart_offered_service_unique_ids = isset($_GET['cart_offered_service_unique_ids']) ? $_GET['cart_offered_service_unique_ids'] : $data['cart_offered_service_unique_ids'];

      $sqlSearchUser = "SELECT unique_id FROM users WHERE unique_id=:unique_id AND status=:status";
      $querySearchUser = $conn->prepare($sqlSearchUser);
      $querySearchUser->bindParam(":unique_id", $user_unique_id);
      $querySearchUser->bindParam(":status", $active);
      $querySearchUser->execute();

      if ($querySearchUser->rowCount() > 0) {

        $validation = $functions->cart_validation($quantity, $description);

        if ($validation["error"] == true) {
          $returnvalue = new genericClass();
          $returnvalue->engineError = 2;
          $returnvalue->engineErrorMessage = $validation["message"];
        }
        else {

          $null = $functions->null;
          $the_description = in_array($description,$not_allowed_values) ? $null : $description;

          // $sql2 = "SELECT quantity, unique_id FROM carts WHERE user_unique_id=:user_unique_id AND product_unique_id=:product_unique_id AND status=:status";
          // $query2 = $conn->prepare($sql2);
          // $query2->bindParam(":user_unique_id", $user_unique_id);
          // $query2->bindParam(":product_unique_id", $product_unique_id);
          // $query2->bindParam(":status", $active);
          // $query2->execute();
          //
          // if ($query2->rowCount() > 0) {
          //
          //   $the_cart_details = $query2->fetch();
          //   $current_quantity = $the_cart_details[0];
          //   $int_quantity = (int)$current_quantity;
          //   $next_quantity = $int_quantity + (int)$quantity;
          //   $cart_unique_id = $the_cart_details[1];
          //
          //   $sql3 = "UPDATE carts SET quantity=:quantity, last_modified=:last_modified WHERE user_unique_id=:user_unique_id AND product_unique_id=:product_unique_id";
          //   $query3 = $conn->prepare($sql3);
          //   $query3->bindParam(":quantity", $next_quantity);
          //   $query3->bindParam(":user_unique_id", $user_unique_id);
          //   $query3->bindParam(":product_unique_id", $product_unique_id);
          //   $query3->bindParam(":last_modified", $date_added);
          //   $query3->execute();
          //
          //   if ($query3->rowCount() > 0) {
          //
          //     if (!in_array($cart_offered_service_unique_ids,$not_allowed_values)) {
          //       foreach ($cart_offered_service_unique_ids as $key => $cart_offered_service_unique_id){
          //
          //         $sql4 = "SELECT unique_id FROM order_services WHERE user_unique_id=:user_unique_id AND cart_unique_id=:cart_unique_id AND offered_service_unique_id=:offered_service_unique_id AND status=:status";
          //         $query4 = $conn->prepare($sql4);
          //         $query4->bindParam(":user_unique_id", $user_unique_id);
          //         $query4->bindParam(":cart_unique_id", $cart_unique_id);
          //         $query4->bindParam(":offered_service_unique_id", $cart_offered_service_unique_id);
          //         $query4->bindParam(":status", $active);
          //         $query4->execute();
          //
          //         if ($query4->rowCount() > 0) {
          //           $returnvalue = new genericClass();
          //           $returnvalue->engineMessage = 1;
          //         }
          //         else {
          //           $order_service_unique_id = $functions->random_str(20);
          //
          //           $sql5 = "INSERT INTO order_services (unique_id, user_unique_id, cart_unique_id, order_unique_id, offered_service_unique_id, added_date, last_modified, status)
          //           VALUES (:unique_id, :user_unique_id, :cart_unique_id, :order_unique_id, :offered_service_unique_id, :added_date, :last_modified, :status)";
          //           $query5 = $conn->prepare($sql5);
          //           $query5->bindParam(":unique_id", $order_service_unique_id);
          //           $query5->bindParam(":user_unique_id", $user_unique_id);
          //           $query5->bindParam(":cart_unique_id", $cart_unique_id);
          //           $query5->bindParam(":order_unique_id", $null);
          //           $query5->bindParam(":offered_service_unique_id", $cart_offered_service_unique_id);
          //           $query5->bindParam(":added_date", $date_added);
          //           $query5->bindParam(":last_modified", $date_added);
          //           $query5->bindParam(":status", $active);
          //           $query5->execute();
          //
          //           if ($query5->rowCount() > 0) {
          //             $returnvalue = new genericClass();
          //             $returnvalue->engineMessage = 1;
          //           }
          //           else{
          //             $counter_now = $key;
          //             $returnvalue = new genericClass();
          //             $returnvalue->engineError = 2;
          //             $returnvalue->engineErrorMessage = $counter_now." index, Not inserted (new order service)";
          //           }
          //
          //         }
          //
          //       }
          //     }
          //     else {
          //       $returnvalue = new genericClass();
          //       $returnvalue->engineMessage = 1;
          //     }
          //
          //   }
          //   else {
          //     $returnvalue = new genericClass();
          //     $returnvalue->engineError = 2;
          //     $returnvalue->engineErrorMessage = "Not edited (new quantity)";
          //   }
          //
          // }
          // else {
          //
          //   $cart_unique_id = $functions->random_str(20);
          //
          //   $sql = "INSERT INTO carts (unique_id, user_unique_id, product_unique_id, quantity, description, added_date, last_modified, status)
          //   VALUES (:unique_id, :user_unique_id, :product_unique_id, :quantity, :description, :added_date, :last_modified, :status)";
          //   $query = $conn->prepare($sql);
          //   $query->bindParam(":unique_id", $cart_unique_id);
          //   $query->bindParam(":user_unique_id", $user_unique_id);
          //   $query->bindParam(":product_unique_id", $product_unique_id);
          //   $query->bindParam(":quantity", $quantity);
          //   $query->bindParam(":description", $the_description);
          //   $query->bindParam(":added_date", $date_added);
          //   $query->bindParam(":last_modified", $date_added);
          //   $query->bindParam(":status", $active);
          //   $query->execute();
          //
          //   if ($query->rowCount() > 0) {
          //
          //     if (!in_array($cart_offered_service_unique_ids,$not_allowed_values)) {
          //       foreach ($cart_offered_service_unique_ids as $key => $cart_offered_service_unique_id){
          //
          //         $order_service_unique_id = $functions->random_str(20);
          //
          //         $sql5 = "INSERT INTO order_services (unique_id, user_unique_id, cart_unique_id, order_unique_id, offered_service_unique_id, added_date, last_modified, status)
          //         VALUES (:unique_id, :user_unique_id, :cart_unique_id, :order_unique_id, :offered_service_unique_id, :added_date, :last_modified, :status)";
          //         $query5 = $conn->prepare($sql5);
          //         $query5->bindParam(":unique_id", $order_service_unique_id);
          //         $query5->bindParam(":user_unique_id", $user_unique_id);
          //         $query5->bindParam(":cart_unique_id", $cart_unique_id);
          //         $query5->bindParam(":order_unique_id", $null);
          //         $query5->bindParam(":offered_service_unique_id", $cart_offered_service_unique_id);
          //         $query5->bindParam(":added_date", $date_added);
          //         $query5->bindParam(":last_modified", $date_added);
          //         $query5->bindParam(":status", $active);
          //         $query5->execute();
          //
          //         if ($query5->rowCount() > 0) {
          //           $returnvalue = new genericClass();
          //           $returnvalue->engineMessage = 1;
          //         }
          //         else{
          //           $counter_now = $key;
          //           $returnvalue = new genericClass();
          //           $returnvalue->engineError = 2;
          //           $returnvalue->engineErrorMessage = $counter_now." index, Not inserted (new order service)";
          //         }
          //
          //       }
          //     }
          //     else {
          //       $returnvalue = new genericClass();
          //       $returnvalue->engineMessage = 1;
          //     }
          //
          //   }
          //   else {
          //     $returnvalue = new genericClass();
          //     $returnvalue->engineError = 2;
          //     $returnvalue->engineErrorMessage = "Not inserted (user cart)";
          //   }
          //
          // }

          $cart_unique_id = $functions->random_str(20);

          $sql = "INSERT INTO carts (unique_id, user_unique_id, product_unique_id, quantity, description, added_date, last_modified, status)
          VALUES (:unique_id, :user_unique_id, :product_unique_id, :quantity, :description, :added_date, :last_modified, :status)";
          $query = $conn->prepare($sql);
          $query->bindParam(":unique_id", $cart_unique_id);
          $query->bindParam(":user_unique_id", $user_unique_id);
          $query->bindParam(":product_unique_id", $product_unique_id);
          $query->bindParam(":quantity", $quantity);
          $query->bindParam(":description", $the_description);
          $query->bindParam(":added_date", $date_added);
          $query->bindParam(":last_modified", $date_added);
          $query->bindParam(":status", $active);
          $query->execute();

          if ($query->rowCount() > 0) {

            if (!in_array($cart_offered_service_unique_ids,$not_allowed_values)) {
              foreach ($cart_offered_service_unique_ids as $key => $cart_offered_service_unique_id){

                $order_service_unique_id = $functions->random_str(20);

                $sql5 = "INSERT INTO order_services (unique_id, user_unique_id, cart_unique_id, order_unique_id, offered_service_unique_id, added_date, last_modified, status)
                VALUES (:unique_id, :user_unique_id, :cart_unique_id, :order_unique_id, :offered_service_unique_id, :added_date, :last_modified, :status)";
                $query5 = $conn->prepare($sql5);
                $query5->bindParam(":unique_id", $order_service_unique_id);
                $query5->bindParam(":user_unique_id", $user_unique_id);
                $query5->bindParam(":cart_unique_id", $cart_unique_id);
                $query5->bindParam(":order_unique_id", $null);
                $query5->bindParam(":offered_service_unique_id", $cart_offered_service_unique_id);
                $query5->bindParam(":added_date", $date_added);
                $query5->bindParam(":last_modified", $date_added);
                $query5->bindParam(":status", $active);
                $query5->execute();

                if ($query5->rowCount() > 0) {
                  $returnvalue = new genericClass();
                  $returnvalue->engineMessage = 1;
                }
                else{
                  $counter_now = $key;
                  $returnvalue = new genericClass();
                  $returnvalue->engineError = 2;
                  $returnvalue->engineErrorMessage = $counter_now." index, Not inserted (new order service)";
                }

              }
            }
            else {
              $returnvalue = new genericClass();
              $returnvalue->engineMessage = 1;
            }

          }
          else {
            $returnvalue = new genericClass();
            $returnvalue->engineError = 2;
            $returnvalue->engineErrorMessage = "Not inserted (user cart)";
          }

        }

      }
      else {
        $returnvalue = new genericClass();
        $returnvalue->engineError = 2;
        $returnvalue->engineErrorMessage = "User not found";
      }

      $conn->commit();
    } catch (PDOException $e) {
      $conn->rollback();
      throw $e;
    }

  }
  else {
    $returnvalue = new genericClass();
    $returnvalue->engineError = 3;
    $returnvalue->engineErrorMessage = "No connection";
  }

  echo json_encode($returnvalue);

?>
