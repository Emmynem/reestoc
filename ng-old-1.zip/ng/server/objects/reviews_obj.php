<?php

  header("Access-Control-Allow-Origin: *");
  header("Content-Type: application/json; charset=UTF-8");
  ini_set('display_errors', 1);

  include_once 'functions.php';

  class Reviews{

      // database connection and table name
      private $conn;
      private $table_name = "reviews";

      // object properties
      public $id;
      public $unique_id;
      public $user_unique_id;
      public $product_unique_id;
      public $message;
      public $yes_rating;
      public $no_rating;
      public $added_date;
      public $last_modified;
      public $status;

      private $functions;
      private $not_allowed_values;

      public $output = array('error' => false, 'success' => false);

      // constructor with $db as database connection
      public function __construct($db){
          $this->conn = $db;
          $this->functions = new Functions();
          $this->not_allowed_values = $this->functions->not_allowed_values;
      }

      function get_all_reviews(){

        try {
          $this->conn->beginTransaction();

          $review_array = array();

          $sql = "SELECT reviews.id, reviews.unique_id, reviews.user_unique_id, reviews.product_unique_id, reviews.message, reviews.added_date, reviews.last_modified, reviews.status, review_ratings.yes_rating as total_yes_rating, review_ratings.no_rating as total_no_rating, users.fullname as user_fullname, users.email as user_email,
          products.name as product_name, products.size as product_size FROM reviews INNER JOIN users ON reviews.user_unique_id = users.unique_id LEFT JOIN products ON reviews.product_unique_id = products.unique_id LEFT JOIN review_ratings ON reviews.unique_id = review_ratings.unique_id ORDER BY reviews.added_date DESC";
          $query = $this->conn->prepare($sql);
          $query->execute();

          $result = $query->fetchAll();

          if ($query->rowCount() > 0) {
            foreach ($result as $key => $value) {

              $current_review = array();
              $current_review['id'] = $value['id'];
              $current_review['unique_id'] = $value['unique_id'];
              $current_review['user_unique_id'] = $value['user_unique_id'];
              $current_review['product_unique_id'] = $value['product_unique_id'];
              $current_review['message'] = $value['message'];
              $current_review['added_date'] = $value['added_date'];
              $current_review['last_modified'] = $value['last_modified'];
              $current_review['status'] = $value['status'];
              $current_review['total_yes_rating'] = $value['total_yes_rating'];
              $current_review['total_no_rating'] = $value['total_no_rating'];
              $current_review['user_fullname'] = $value['user_fullname'];
              $current_review['user_email'] = $value['user_email'];
              $current_review['product_name'] = $value['product_name'];
              $current_review['product_size'] = $value['product_size'];

              $review_id = $value['unique_id'];

              $sql2 = "SELECT image FROM review_images WHERE review_unique_id=:review_unique_id";
              $query2 = $this->conn->prepare($sql2);
              $query2->bindParam(":review_unique_id", $review_id);
              $query2->execute();

              $images_result = $query2->fetchAll();

              if ($query2->rowCount() > 0) {
                $current_review_images = array();

                foreach ($images_result as $key => $image_value) {
                  $current_review_images[] = $image_value['image'];
                }

                $current_review['review_images'] = $current_review_images;
              }
              else{
                $current_review['review_images'] = null;
              }

              $review_array[] = $current_review;
            }
            return $review_array;
          }
          else {
            $output['error'] = true;
            $output['message'] = "Empty";
            return $output;
          }

          $this->conn->commit();
        } catch (PDOException $e) {
          $this->conn->rollback();
          throw $e;
        }

      }

      function get_all_user_reviews($user_unique_id){
        if (!in_array($user_unique_id,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $review_array = array();

            $sql = "SELECT reviews.id, reviews.unique_id, reviews.user_unique_id, reviews.product_unique_id, reviews.message, reviews.added_date, reviews.last_modified, reviews.status, review_ratings.yes_rating as total_yes_rating, review_ratings.no_rating as total_no_rating, users.fullname as user_fullname, users.email as user_email,
            products.name as product_name, products.size as product_size FROM reviews INNER JOIN users ON reviews.user_unique_id = users.unique_id LEFT JOIN products ON reviews.product_unique_id = products.unique_id LEFT JOIN review_ratings ON reviews.unique_id = review_ratings.unique_id WHERE reviews.user_unique_id=:user_unique_id ORDER BY reviews.added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":user_unique_id", $user_unique_id);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              foreach ($result as $key => $value) {

                $current_review = array();
                $current_review['id'] = $value['id'];
                $current_review['unique_id'] = $value['unique_id'];
                $current_review['user_unique_id'] = $value['user_unique_id'];
                $current_review['product_unique_id'] = $value['product_unique_id'];
                $current_review['message'] = $value['message'];
                $current_review['added_date'] = $value['added_date'];
                $current_review['last_modified'] = $value['last_modified'];
                $current_review['status'] = $value['status'];
                $current_review['total_yes_rating'] = $value['total_yes_rating'];
                $current_review['total_no_rating'] = $value['total_no_rating'];
                $current_review['user_fullname'] = $value['user_fullname'];
                $current_review['user_email'] = $value['user_email'];
                $current_review['product_name'] = $value['product_name'];
                $current_review['product_size'] = $value['product_size'];

                $review_id = $value['unique_id'];

                $sql2 = "SELECT image FROM review_images WHERE review_unique_id=:review_unique_id";
                $query2 = $this->conn->prepare($sql2);
                $query2->bindParam(":review_unique_id", $review_id);
                $query2->execute();

                $images_result = $query2->fetchAll();

                if ($query2->rowCount() > 0) {
                  $current_review_images = array();

                  foreach ($images_result as $key => $image_value) {
                    $current_review_images[] = $image_value['image'];
                  }

                  $current_review['review_images'] = $current_review_images;
                }
                else{
                  $current_review['review_images'] = null;
                }

                $review_array[] = $current_review;
              }
              return $review_array;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }

      }

      function get_all_product_reviews($product_unique_id){
        if (!in_array($product_unique_id,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $review_array = array();

            $sql = "SELECT reviews.id, reviews.unique_id, reviews.user_unique_id, reviews.product_unique_id, reviews.message, reviews.added_date, reviews.last_modified, reviews.status, review_ratings.yes_rating as total_yes_rating, review_ratings.no_rating as total_no_rating, users.fullname as user_fullname, users.email as user_email,
            products.name as product_name, products.size as product_size FROM reviews INNER JOIN users ON reviews.user_unique_id = users.unique_id LEFT JOIN products ON reviews.product_unique_id = products.unique_id LEFT JOIN review_ratings ON reviews.unique_id = review_ratings.unique_id WHERE reviews.product_unique_id=:product_unique_id ORDER BY reviews.added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":product_unique_id", $product_unique_id);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              foreach ($result as $key => $value) {

                $current_review = array();
                $current_review['id'] = $value['id'];
                $current_review['unique_id'] = $value['unique_id'];
                $current_review['user_unique_id'] = $value['user_unique_id'];
                $current_review['product_unique_id'] = $value['product_unique_id'];
                $current_review['message'] = $value['message'];
                $current_review['added_date'] = $value['added_date'];
                $current_review['last_modified'] = $value['last_modified'];
                $current_review['status'] = $value['status'];
                $current_review['total_yes_rating'] = $value['total_yes_rating'];
                $current_review['total_no_rating'] = $value['total_no_rating'];
                $current_review['user_fullname'] = $value['user_fullname'];
                $current_review['user_email'] = $value['user_email'];
                $current_review['product_name'] = $value['product_name'];
                $current_review['product_size'] = $value['product_size'];

                $review_id = $value['unique_id'];

                $sql2 = "SELECT image FROM review_images WHERE review_unique_id=:review_unique_id";
                $query2 = $this->conn->prepare($sql2);
                $query2->bindParam(":review_unique_id", $review_id);
                $query2->execute();

                $images_result = $query2->fetchAll();

                if ($query2->rowCount() > 0) {
                  $current_review_images = array();

                  foreach ($images_result as $key => $image_value) {
                    $current_review_images[] = $image_value['image'];
                  }

                  $current_review['review_images'] = $current_review_images;
                }
                else{
                  $current_review['review_images'] = null;
                }

                $review_array[] = $current_review;
              }
              return $review_array;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }

      }

  }
?>
