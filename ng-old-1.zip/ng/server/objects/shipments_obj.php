<?php

  header("Access-Control-Allow-Origin: *");
  header("Content-Type: application/json; charset=UTF-8");
  ini_set('display_errors', 1);

  include_once 'functions.php';

  class Shipments{

      // database connection and table name
      private $conn;
      private $table_name = "shipments";

      // object properties
      public $id;
      public $unique_id;
      public $shipment_unique_id;
      public $rider_unique_id;
      public $current_location;
      public $longitude;
      public $latitude;
      public $delivery_status;
      public $added_date;
      public $last_modified;
      public $status;

      private $functions;
      private $not_allowed_values;

      public $output = array('error' => false, 'success' => false);

      // constructor with $db as database connection
      public function __construct($db){
          $this->conn = $db;
          $this->functions = new Functions();
          $this->not_allowed_values = $this->functions->not_allowed_values;
      }

      function get_all_shipments(){

        try {
          $this->conn->beginTransaction();

          $sql = "SELECT shipments.id, shipments.unique_id, shipments.shipment_unique_id, shipments.rider_unique_id, shipments.current_location, shipments.longitude, shipments.latitude,
          shipments.delivery_status, shipments.added_date, shipments.last_modified, shipments.status, riders.fullname as rider_fullname FROM shipments
          INNER JOIN riders ON shipments.rider_unique_id = riders.unique_id ORDER BY shipments.added_date DESC";
          $query = $this->conn->prepare($sql);
          $query->execute();

          $result = $query->fetchAll();

          if ($query->rowCount() > 0) {
            return $result;
          }
          else {
            $output['error'] = true;
            $output['message'] = "Empty";
            return $output;
          }

          $this->conn->commit();
        } catch (PDOException $e) {
          $this->conn->rollback();
          throw $e;
        }

      }

      function get_rider_shipments($rider_unique_id){
        if (!in_array($rider_unique_id,$this->not_allowed_values)) {
          try {
            $this->conn->beginTransaction();

            $sql = "SELECT shipments.id, shipments.unique_id, shipments.shipment_unique_id, shipments.rider_unique_id, shipments.current_location, shipments.longitude, shipments.latitude,
            shipments.delivery_status, shipments.added_date, shipments.last_modified, shipments.status, riders.fullname as rider_fullname FROM shipments
            INNER JOIN riders ON shipments.rider_unique_id = riders.unique_id WHERE shipments.rider_unique_id=:rider_unique_id ORDER BY shipments.added_date DESC";
            $query = $this->conn->prepare($sql);
            $query->bindParam(":rider_unique_id", $rider_unique_id);
            $query->execute();

            $result = $query->fetchAll();

            if ($query->rowCount() > 0) {
              return $result;
            }
            else {
              $output['error'] = true;
              $output['message'] = "Empty";
              return $output;
            }

            $this->conn->commit();
          } catch (PDOException $e) {
            $this->conn->rollback();
            throw $e;
          }
        }
        else {
          $output['error'] = true;
          $output['message'] = "All fields are required";
          return $output;
        }

      }

  }
?>
